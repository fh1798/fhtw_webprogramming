import { Component } from '@angular/core';

@Component({
  selector: 'app-conversation',
  imports: [],
  templateUrl: './conversation.component.html',
  styleUrl: './conversation.component.css'
})
export class ConversationComponent {

}
