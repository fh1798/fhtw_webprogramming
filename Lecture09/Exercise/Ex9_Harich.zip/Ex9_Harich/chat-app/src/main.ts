import { ChatUI } from "./ChatUI.js";
new ChatUI();