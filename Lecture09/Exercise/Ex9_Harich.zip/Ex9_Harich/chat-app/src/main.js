"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ChatUI_js_1 = require("./ChatUI.js");
new ChatUI_js_1.ChatUI();
